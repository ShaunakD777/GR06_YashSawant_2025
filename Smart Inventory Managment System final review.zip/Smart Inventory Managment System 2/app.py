from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')

# MySQL Configuration
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD')
app.config['MYSQL_DB'] = os.getenv('MYSQL_DB')

mysql = MySQL(app)
bcrypt = Bcrypt(app)

# Routes
@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()
        if user and bcrypt.check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        role = 'user'
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (username, email, password, role) VALUES (%s, %s, %s, %s)",
                    (username, email, password, role))
        mysql.connection.commit()
        cur.close()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()

    # Fetch total sales for cross sales
    cur.execute("SELECT SUM(total_price) FROM orders WHERE status = 'completed'")
    total_sales = cur.fetchone()[0] or 0

    # Fetch today's sales for cross sales percentage
    cur.execute("SELECT SUM(total_price) FROM orders WHERE status = 'completed' AND DATE(created_at) = CURDATE()")
    today_sales = cur.fetchone()[0] or 0
    cross_sales_percentage = (today_sales / total_sales * 100) if total_sales > 0 else 0

    # Fetch average sales
    cur.execute("SELECT AVG(total_price) FROM orders WHERE status = 'completed'")
    average_sales = cur.fetchone()[0] or 0

    # Fetch new sales (orders created today)
    cur.execute("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()")
    new_sales = cur.fetchone()[0] or 0

    # Fetch yesterday's sales for percentage calculations
    cur.execute("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)")
    yesterday_sales = cur.fetchone()[0] or 0
    new_sales_percentage = ((new_sales - yesterday_sales) / yesterday_sales * 100) if yesterday_sales > 0 else 0

    # Prepare sales data
    sales_data = {
        'cross_sales': total_sales,
        'cross_sales_percentage': round(cross_sales_percentage, 2),
        'average_sales': round(average_sales, 2),
        'average_sales_percentage': 23,  # Example, replace with dynamic calculation if needed
        'new_sales': new_sales,
        'new_sales_percentage': round(new_sales_percentage, 2),
    }

    # Fetch top products
    cur.execute("""
        SELECT p.name, s.name AS supplier, p.stock_quantity, SUM(oi.quantity) AS sales
        FROM products p
        JOIN order_items oi ON p.id = oi.product_id
        JOIN suppliers s ON p.supplier_id = s.id
        GROUP BY p.id
        ORDER BY sales DESC
        LIMIT 5
    """)
    top_products = cur.fetchall()

    # Fetch revenue data for the chart
    cur.execute("""
        SELECT MONTH(o.created_at) AS month, SUM(o.total_price) AS revenue
        FROM orders o
        WHERE o.status = 'completed'
        GROUP BY MONTH(o.created_at)
    """)
    revenue_data = [0] * 12
    for row in cur.fetchall():
        revenue_data[row[0] - 1] = row[1]

    # Fetch cost data for the chart (quantity * product cost)
    cur.execute("""
        SELECT MONTH(o.created_at) AS month, SUM(oi.quantity * p.cost) AS cost
        FROM orders o
        JOIN order_items oi ON o.id = oi.order_id
        JOIN products p ON oi.product_id = p.id
        WHERE o.status = 'completed'
        GROUP BY MONTH(o.created_at)
    """)
    costs_data = [0] * 12
    for row in cur.fetchall():
        costs_data[row[0] - 1] = row[1]

    # Fetch revenue breakdown by product category for the pie chart
    cur.execute("""
        SELECT p.category, SUM(o.total_price) AS revenue
        FROM orders o
        JOIN order_items oi ON o.id = oi.order_id
        JOIN products p ON oi.product_id = p.id
        WHERE o.status = 'completed'
        GROUP BY p.category
    """)
    revenue_breakdown = cur.fetchall()

    cur.close()

    # Prepare data for the pie chart
    pie_labels = [row[0] for row in revenue_breakdown]
    pie_data = [row[1] for row in revenue_breakdown]

    return render_template('dashboard.html', sales_data=sales_data, top_products=top_products, revenue_data=revenue_data, costs_data=costs_data, pie_labels=pie_labels, pie_data=pie_data)

@app.route('/products')
def products():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM products")
    products = cur.fetchall()
    cur.close()
    return render_template('products.html', products=products)

@app.route('/orders')
def orders():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()
    cur.execute("""
    SELECT o.id, p.name, oi.quantity, o.total_price, o.created_at, o.status
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    ORDER BY o.id
""")
    orders = cur.fetchall()
    cur.close()

    return render_template('orders.html', orders=orders)

@app.route('/suppliers')
def suppliers():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM suppliers")
    suppliers = cur.fetchall()
    cur.close()
    return render_template('suppliers.html', suppliers=suppliers)

@app.route('/add-product', methods=['GET', 'POST'])
def add_product():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = float(request.form['price'])
        stock_quantity = int(request.form['stock_quantity'])
        category = request.form['category']
        image = request.form['image']
        supplier_id = int(request.form['supplier_id'])

        cur = mysql.connection.cursor()

        # Insert product into database (cost will be calculated by the trigger)
        cur.execute("""
            INSERT INTO products (name, description, price, stock_quantity, category, image, supplier_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (name, description, price, stock_quantity, category, image, supplier_id))

        mysql.connection.commit()
        cur.close()

        flash("Product added successfully!", "success")
        return redirect(url_for('dashboard'))

    # If the request method is GET, render the add_product.html template
    return render_template('add_product.html')


@app.route('/delete-product/<int:product_id>')
def delete_product(product_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM products WHERE id = %s", (product_id,))
    mysql.connection.commit()
    cur.close()

    flash('Product deleted successfully!', 'success')
    return redirect(url_for('products'))

@app.route('/sell-product/<int:product_id>', methods=['GET', 'POST'])
def sell_product(product_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        quantity = int(request.form['quantity'])
        selling_price = float(request.form['selling_price'])  # Capture selling price

        cur = mysql.connection.cursor()

        # Fetch product details
        cur.execute("SELECT price, stock_quantity FROM products WHERE id = %s", (product_id,))
        product = cur.fetchone()
        if not product:
            flash('Product not found!', 'danger')
            return redirect(url_for('products'))

        product_price, stock_quantity = product

        # Check if there is enough stock
        if stock_quantity < quantity:
            flash('Insufficient stock!', 'danger')
            return redirect(url_for('products'))

        # Update stock quantity
        cur.execute("UPDATE products SET stock_quantity = stock_quantity - %s WHERE id = %s", (quantity, product_id))

        # Create a new order with status 'completed'
        cur.execute("""
            INSERT INTO orders (user_id, total_price, status)
            VALUES (%s, %s, 'completed')
        """, (session['user_id'], quantity * selling_price))  # Use the logged-in user's ID
        order_id = cur.lastrowid  # Get the ID of the newly created order

        # Insert into order_items with selling price
        cur.execute("""
            INSERT INTO order_items (order_id, product_id, quantity, price, selling_price)
            VALUES (%s, %s, %s, %s, %s)
        """, (order_id, product_id, quantity, product_price, selling_price))

        mysql.connection.commit()
        cur.close()

        flash(f'{quantity} units sold successfully at ₹{selling_price} each!', 'success')
        return redirect(url_for('products'))

    return render_template('sell_product.html', product_id=product_id)

@app.route('/add-supplier', methods=['GET', 'POST'])
def add_supplier():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        contact_name = request.form['contact_name']
        contact_email = request.form['contact_email']
        contact_phone = request.form['contact_phone']
        address = request.form['address']

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO suppliers (name, contact_name, contact_email, contact_phone, address)
            VALUES (%s, %s, %s, %s, %s)
        """, (name, contact_name, contact_email, contact_phone, address))
        mysql.connection.commit()
        cur.close()

        flash('Supplier added successfully!', 'success')
        return redirect(url_for('suppliers'))

    return render_template('add_supplier.html')

@app.route('/delete-supplier/<int:supplier_id>')
def delete_supplier(supplier_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM suppliers WHERE id = %s", (supplier_id,))
    mysql.connection.commit()
    cur.close()

    flash('Supplier deleted successfully!', 'success')
    return redirect(url_for('suppliers'))

@app.route('/add-order', methods=['GET', 'POST'])
def add_order():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        user_id = int(request.form['user_id'])
        product_id = int(request.form['product_id'])
        quantity = int(request.form['quantity'])
        selling_price = float(request.form['selling_price'])
        status = request.form['status']  # Add status field

        # Calculate total price
        total_price = quantity * selling_price

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO orders (user_id, total_price, status)
            VALUES (%s, %s, %s)
        """, (user_id, total_price, status))

        # Insert into order_items
        cur.execute("""
            INSERT INTO order_items (order_id, product_id, quantity, price, selling_price)
            VALUES (%s, %s, %s, %s, %s)
        """, (cur.lastrowid, product_id, quantity, selling_price, selling_price))

        mysql.connection.commit()
        cur.close()

        flash('Order added successfully!', 'success')
        return redirect(url_for('orders'))

    # Fetch products for the dropdown (GET request)
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name FROM products")
    products = cur.fetchall()
    cur.close()

    return render_template('add_order.html', products=products)

@app.route('/delete-order/<int:order_id>')
def delete_order(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM orders WHERE id = %s", (order_id,))
    mysql.connection.commit()
    cur.close()

    flash('Order deleted successfully!', 'success')
    return redirect(url_for('orders'))

@app.route('/edit-order/<int:order_id>', methods=['GET', 'POST'])
def edit_order(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()

    if request.method == 'POST':
        quantity = int(request.form['quantity'])
        selling_price = float(request.form['selling_price'])
        status = request.form['status']  # Capture status correctly

        # Update order_items table
        cur.execute("""
            UPDATE order_items
            SET quantity = %s, selling_price = %s
            WHERE order_id = %s
        """, (quantity, selling_price, order_id))

        # Ensure that orders table is updated properly
        cur.execute("""
            UPDATE orders
            SET total_price = %s, status = %s
            WHERE id = %s
        """, (quantity * selling_price, status, order_id))

        mysql.connection.commit()
        cur.close()

        flash('Order updated successfully!', 'success')
        return redirect(url_for('orders'))

    # Fetch order details (Ensure no issues with missing values)
    cur.execute("""
        SELECT o.id, p.name, oi.quantity, oi.selling_price, o.status
        FROM orders o
        JOIN order_items oi ON o.id = oi.order_id
        JOIN products p ON oi.product_id = p.id
        WHERE o.id = %s
    """, (order_id,))
    order = cur.fetchone()
    cur.close()

    if not order:
        flash('Order not found!', 'danger')
        return redirect(url_for('orders'))

    return render_template('edit_order.html', order=order)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

from flask import make_response
import csv
import io

@app.route('/export-products-csv')
def export_products_csv():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor()

    # Fetch product details
    cur.execute("""
        SELECT p.name, p.cost, p.price, p.created_at, MIN(o.created_at) AS first_sale_date
        FROM products p
        LEFT JOIN order_items oi ON p.id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.id
        GROUP BY p.id
    """)
    products = cur.fetchall()
    cur.close()

    # Debug: Print fetched data
    print("Fetched Products:", products)

    # Create a CSV file in memory
    output = io.StringIO()
    writer = csv.writer(output)

    # Write CSV header
    writer.writerow(['Product Name', 'Cost', 'Selling Price', 'Date Added', 'Date Sold'])

    # Write product data
    for product in products:
        writer.writerow([
            product[0],  # Product Name
            product[1],  # Cost
            product[2],  # Selling Price
            product[3].strftime('%Y-%m-%d %H:%M:%S') if product[3] else '',  # Date Added
            product[4].strftime('%Y-%m-%d %H:%M:%S') if product[4] else '',  # Date Sold
        ])

    # Debug: Print CSV content
    print("CSV Content:", output.getvalue())

    # Prepare the response
    output.seek(0)
    response = make_response(output.getvalue())
    response.headers['Content-Disposition'] = 'attachment; filename=products_export.csv'
    response.headers['Content-type'] = 'text/csv'

    return response

if __name__ == '__main__':
    app.run(debug=True)